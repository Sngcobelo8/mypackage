# mypackage
This library was created as an example of how to publish your own python package.

## Building this package locally
python setup.py sdist

## Installing this package from github

pip install git+https://github.com/Sngcobelo8/mypackage

## Updating this package from github
pip install --upgrade git+https://github.com/Sngcobelo8/mypackage